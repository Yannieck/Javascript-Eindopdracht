class Enemy {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.size = 10;
        this.angle = 0;
        this.speed = 0;
    }
}

var ENEMYS = [];